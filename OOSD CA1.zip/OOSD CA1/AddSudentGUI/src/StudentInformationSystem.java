import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

//Instance Variables
public class StudentInformationSystem {
	private ArrayList<String> studentListStorage = new ArrayList<String>();//Defining the ArrayList
	private JFrame frame;
	//Creating a constructor method
	public StudentInformationSystem() {
		frame = new JFrame("Student Registration");//creating a frame object
		frame.setLayout(new BorderLayout());//placing the JFrame into a BorderLayout
		
        // Creating PanelNewStudent (Main Panel) and the 3 other panels
        JPanel panelNewStudent = new JPanel(new BorderLayout());
        frame.add(panelNewStudent, BorderLayout.CENTER);//adding the panel to the center of the frame
        TitledBorder titledBorder = BorderFactory.createTitledBorder("New Student");
        Border bevelBorder = BorderFactory.createRaisedBevelBorder();//Easy to mix
        panelNewStudent.setBorder(BorderFactory.createCompoundBorder(bevelBorder, titledBorder));//combines the two border types
        
        JPanel panelAddStudent = new JPanel(new GridLayout(3, 2));
        panelNewStudent.add(panelAddStudent, BorderLayout.NORTH);//setting the AddStudent panel to north inside the NewStudent panel
        
        JPanel panelShowStudent = new JPanel(new BorderLayout());
        panelNewStudent.add(panelShowStudent, BorderLayout.CENTER);//setting the ShowStudent panel to center inside the NewStudent panel
        
        JPanel panelModules = new JPanel(new GridLayout(2, 1));
        panelNewStudent.add(panelModules, BorderLayout.EAST);//setting the Modules panel to east inside the NewStudent panel
        
        //Creating components and adding them to PanelAddStudent
        JLabel nameLabel = new JLabel("Name:");//Label displaying Name:
        panelAddStudent.add(nameLabel);
        JTextField nameTextField = new JTextField("Peter Smith");//TextField with a default name
        panelAddStudent.add(nameTextField);
        JLabel addressLabel = new JLabel("Address:");//Label displaying Subject:
        panelAddStudent.add(addressLabel);
        JTextField addressTextField = new JTextField("35 Liffey Street, Dublin 2");//TextField with a default address
        panelAddStudent.add(addressTextField);
        JButton btnSubmit = new JButton("Submit");//creating a button called Submit -- ACTION LISTNER
        panelAddStudent.add(btnSubmit);
        JButton btnClear = new JButton("Clear");//creating a button called Clear -- ACTION LISTER
        panelAddStudent.add(btnClear);
        
        //Creating components and adding them to PanelShowStudent
        JLabel studentList = new JLabel("Student List:");//creating the Label above the TextArea
        panelShowStudent.add(studentList, BorderLayout.NORTH);
        JTextArea txtrShowStudents = new JTextArea();//Creating the TextArea where the Students info will be displayed
        panelShowStudent.add(new JScrollPane(txtrShowStudents), BorderLayout.CENTER);
        txtrShowStudents.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));//padding
        
        //PanelModules already created in Line 41 - adding a panels called panelCheckBoxes and a textArea called moduleList to the PanelModules
        JPanel panelCheckBoxes = new JPanel(new GridLayout(0, 1));//creating a panelCheckBox which holds the modules
        JCheckBox module1 = new JCheckBox("Database");//-- ACTION LISTENER
        panelCheckBoxes.add(module1);
        JCheckBox module2 = new JCheckBox("Java");//-- ACTION LISTENER
        panelCheckBoxes.add(module2);
        JCheckBox module3 = new JCheckBox("Accountancy");//-- ACTION LISTENER
        panelCheckBoxes.add(module3);
        JTextArea moduleList = new JTextArea();
        panelModules.add(panelCheckBoxes);
        panelModules.add(new JScrollPane(moduleList));
        
        //Creating the panelButtons panel and positioning it in the frame
		JPanel panelButtons = new JPanel();
		frame.add(panelButtons, BorderLayout.SOUTH);//adding the panel to the south of the frame
        
        //Creating a Finish and Clear All button
        JButton btnFinish = new JButton("Finish");//-- ACTION LISTENER
        panelButtons.add(btnFinish);
        JButton btnClearAll = new JButton("Clear All");//-- ACTION LISTENER
        panelButtons.add(btnClearAll);
		
		//Frame Appearance and functionality
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//set what happens when they close the frame
        frame.pack();//making sure all the components are correctly sized
        frame.setSize(800, 400);//set size of the frame
        frame.setVisible(true);//makes the frame visible
        
    	//-------------ACTION LISTENER--------------
    	btnSubmit.addActionListener(new ActionListener(){
    		@Override
    		public void actionPerformed(ActionEvent e) {
    			String name = nameTextField.getText();
    			String address = addressTextField.getText();
    			//ArrayList--------------------------------
    			String studentInfo = name + ", " + address;
    	    	studentListStorage.add(studentInfo);
    	    	//ArrayList--------------------------------
    			txtrShowStudents.append(name + ", " + address + "\n");//preserves the existing content in the text area and extend it with the new student's information when the "Submit" button is clicked.
    		}
    	});
    	
    	btnClear.addActionListener(new ActionListener(){
    	   @Override
    	   public void actionPerformed(ActionEvent e) {
    		   nameTextField.setText("");
    		   addressTextField.setText("");
    	   }
    	});
    	
    	btnFinish.addActionListener(new ActionListener() {
    		@Override
    		public void actionPerformed(ActionEvent e) {
    			System.exit(0); //closes the program
    		}
    	});
    	
    	btnClearAll.addActionListener(new ActionListener() {
    		@Override
    		public void actionPerformed(ActionEvent e) {
    			nameTextField.setText("");
     		    addressTextField.setText("");
     		    txtrShowStudents.setText("");
     		    module1.setSelected(false);
     		    module2.setSelected(false);
     		    module3.setSelected(false);
     		    moduleList.setText("");
    	}
	});
    	
    	module1.addActionListener(new ActionListener() {
    	    @Override
    	    public void actionPerformed(ActionEvent e) {
    	        if (module1.isSelected()) {
    	            moduleList.append("Database\n");
    	        } else {
    	            // Remove the module name if deselected
    	            String text = moduleList.getText();
    	            moduleList.setText(text.replace("Database\n", ""));
    	        }
    	    }
    	});

    	module2.addActionListener(new ActionListener() {
    	    @Override
    	    public void actionPerformed(ActionEvent e) {
    	        if (module2.isSelected()) {
    	            moduleList.append("Java\n");
    	        } else {
    	            // Remove the module name if deselected
    	            String text = moduleList.getText();
    	            moduleList.setText(text.replace("Java\n", ""));
    	        }
    	    }
    	});

    	module3.addActionListener(new ActionListener() {
    	    @Override
    	    public void actionPerformed(ActionEvent e) {
    	        if (module3.isSelected()) {
    	            moduleList.append("Accountancy\n");
    	        } else {
    	            // Remove the module name if deselected
    	            String text = moduleList.getText();
    	            moduleList.setText(text.replace("Accountancy\n", ""));
    	        }
    	    }
    	});
    	
    	for (int i = 0; i < studentListStorage.size(); i++) {
    	    System.out.println(studentListStorage.get(i));
    	}


}
    	

	public static void main(String[] args) {
	
		new StudentInformationSystem();

	}

}
